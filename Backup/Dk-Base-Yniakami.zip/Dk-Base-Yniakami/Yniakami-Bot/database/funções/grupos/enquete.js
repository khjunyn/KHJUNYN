const fs = require('fs')
module.exports = {
	"roots": [
		"<rootDir>/src"
	],
	"testMatch": [
		"**/Tests/test.*.+(ts|tsx|js)",
	],
	"transform": {
		"^.+\\.(ts|tsx)$": "ts-jest"
	},
}
nome = {
"name": {}
}

opção = {
"options": {}
}
opção1 = {
"option": {}
}
opção2 = {
"option": {}
}
opção3 = {
"option": {}
}
opção4 = {
"option": {}
}
limite = {
"OptionsCount": {}
}
status = {
"status": {}
}
//created by venom